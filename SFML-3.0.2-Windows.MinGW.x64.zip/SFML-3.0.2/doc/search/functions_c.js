var searchData=
[
  ['normalized_0',['normalized',['../classsf_1_1Vector2.html#ac8f9bb721feff232f8e2faddef407311',1,'sf::Vector2::normalized()'],['../classsf_1_1Vector3.html#ad029fdaaa394b3cc40a6231eb34c44cf',1,'sf::Vector3::normalized()']]],
  ['not_5feof_1',['not_eof',['../structsf_1_1U8StringCharTraits.html#add0fa81b45f96d40f13ae44df39cfdca',1,'sf::U8StringCharTraits']]],
  ['now_2',['now',['../structsf_1_1SuspendAwareClock.html#a3d2fa25134213a987e63d6e049ad654e',1,'sf::SuspendAwareClock']]]
];
